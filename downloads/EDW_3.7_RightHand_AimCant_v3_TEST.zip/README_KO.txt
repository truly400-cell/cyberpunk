﻿EDW3.7 오른손 조준 기울기 패치 v3 TEST

v3의 변경
v2 사용자가 requested=45 effective=45 reason=active인 상태에서도 시각 변화가 없다고 확인했습니다.
v1/v2 새 노드가 nodesToInit 초기화 목록에 빠진 것을 발견했습니다.
v3는 새 노드3개(손 회전/각도 보간/기능 입력)를 초기화 목록과 소유 노드 목록 양쪽에 등록합니다.
또 하위 ADS 분기 대신 상위 player_base의 최종 출력 직전에 회전을 연결하여
그래프 내부의 이후 IK/방향 제약 노드가 회전을 다시 덮는 경로를 피하도록 바꿨습니다.
하위 player_dualwield 그래프는 원본 EDW3.7 데이터 그대로 복원하여 이중 회전을 방지했습니다.
이 변경이 실제 게임의 모든 후처리/다른 모드 충돌을 해결했는지는 아직 미검증입니다.

설치
1. 게임을 완전히 종료합니다. Reload all mods로는 새 redscript/그래프를 로드할 수 없습니다.
2. 원본 Expanded Dual Wielding3.7은 켜둡니다.
3. 모드 매니저는 이전 v1/v2 기울기 패치를 끄고 이 v3 패치를 켭니다.
   수동 설치는 ZIP의 archive/bin/r6를 게임 폴더에 풀어 같은 경로에 덮어씁니다.
   archive 이름은 이전 버전과 동일하게 유지해 중복 파일이 남지 않게 했습니다.
   !!!!_EDW_RightHand_AimCant_v1_TEST.archive라는 이름이어도 이 ZIP의 내용은 v3입니다.
4. 게임에서 양손 SMG/AR/산탄총 등을 들고 LT(기본 CameraAim 액션)로 조준합니다.
   권총/리볼버 오른손은 원본 포즈를 유지합니다. 단일 무기/근접 혼합/사이버웨어는 제외합니다.
5. CET의 EDW Right-hand Aim Cant 창에서 Enable과45도를 확인합니다.
   각도는 -60~60도이며 CET를 닫으면 적용합니다. 원래 게임 입력을 소비하거나 바꾸지 않습니다.

입력/적용
CameraAim 입력 리스너 또는 상체 조준 상태(UpperBody6)에서 추가 기울기를 켭니다.
LT를 놓고 조준이 끝나면0도로 돌아갑니다. 재장전/무기 교체/메뉴/차량/비생존 상태는 제외합니다.
새 회전 노드는 각도를 보간하여 약0.1초에45도까지 바뀝니다.
독립 조작 옵션을 켤 필요는 없습니다.

시각 테스트 — 입력과 별개로 최종 그래프를 확인
양손에 대상 원거리 무기를 들고 CET 창의 Test pose for 3s after closing CET를 누른 뒤
CET를 닫습니다. LT를 누르지 않아도 약3초간 오른손이 기울었다가 돌아가도록 요청합니다.
콘솔 명령으로도 가능합니다:
GetMod("EDWRightCant").test()
반드시 CET를 닫아야 테스트가 시작됩니다. Enable이 켜져 있어야 합니다.

진단
GetMod("EDWRightCant").status()
[EDWRightCant v3]가 나와야 합니다.
effective: 직전 게임 업데이트에서 요청한 각도. lastAim: 최근 조준/테스트에서의 각도.
input: 감지한 CameraAim 값. LT를 놓은 후에는 input/effective가0이어도 정상입니다.
reason=active: 대상 쌍수 조준 또는 CameraAim 감지.
reason=test_pose:3초 테스트 중.
reason=not_aiming: 대상 쌍수지만 조준/LT/테스트 요청 없음.
reason=reload_or_switch / menu / vehicle / scene / not_alive: 해당 상황에서 제외.
reason=pistol_pose_preserved: 오른손 권총/리볼버의 기존 포즈 유지.
reason=two_weapons_required / two_ranged_weapons_required: 대상 쌍수 조합 아님.
reason=zero_angle_or_disabled: 설정0도 또는OFF.
requested/effective/lastAim 값은 스크립트 요청이며 실제 회전이나 archive 우선순위의 증명은 아닙니다.

3초 테스트도 시각 변화가 없으면 player_base를 덮는 다른 모드/아카이브 우선순위 또는
게임의 추가 후처리 등을 확인해야 합니다. 그 경우 LT 조건을 바꾸는 것만으로는 해결되지 않습니다.

검증
공식 WolvenKit8.18.0 추출/수정/재패킹/재추출을 수행했습니다.
두 그래프의 재추출 파일은 패킹 입력과 바이트 단위로 같습니다.
새 노드3개의 초기화/소유자 등록 및 최종 출력 연결을 재직렬화된 파일에서 확인했습니다.
새 노드/연결/등록/기능 항목을 제외한 상위 원본 그래프 Data가 모두 보존됩니다.
하위 그래프는 원본 EDW3.7과 바이트 단위로 같습니다.
CET Lua 문법/설정/범위/저장/활성화/오버레이중 보류/지연 테스트 요청/종료 검사를 통과했습니다.
Windows 게임 로딩, redscript 컴파일, 실제 자세/좌우 대칭/부착물 간섭은 미검증입니다.

삭제
게임 종료 후 아래 패치 경로만 제거합니다. 원본 EDW3.7은 지우지 않습니다.
archive/pc/mod/!!!!_EDW_RightHand_AimCant_v1_TEST.archive
r6/scripts/EDWRightCant/
bin/x64/plugins/cyber_engine_tweaks/mods/EDWRightCant/
EDW3.7 전용입니다. 원본 EDW 업데이트 시 이 패치를 먼저 제거하세요.
