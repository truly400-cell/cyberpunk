// Expanded Dual Wielding 3.7 add-on: only the graph's right ADS branch reads this feature.
public class EDWAnimFeature_RightCant extends AnimFeature {
  public let angle: Float;
}

@addField(PlayerPuppet)
private let edwRightCantInitialized: Bool;
@addField(PlayerPuppet)
private let edwRightCantLastAngle: Float;

@addMethod(PlayerPuppet)
public final func EDWConfigureRightCant(requestedAngle: Float) -> Void {
  let angle = 0.0;
  let right = GameObject.GetRightActiveWeapon(this);
  let left = GameObject.GetLeftActiveWeapon(this);
  if EDWInput.PoseContext(this) && IsDefined(right) && IsDefined(left) {
    if WeaponObject.IsRanged(right.GetItemID()) && WeaponObject.IsRanged(left.GetItemID())
      && !right.WeaponHasTag(n"Cyberware") && !left.WeaponHasTag(n"Cyberware") {
      let record = right.GetWeaponRecord();
      if IsDefined(record) && IsDefined(record.ItemType()) {
        let weaponType = record.ItemType().Type();
        if NotEquals(weaponType, gamedataItemType.Wea_Handgun)
          && NotEquals(weaponType, gamedataItemType.Wea_Revolver) {
          angle = ClampF(requestedAngle, -60.0, 60.0);
        }
      }
    }
  }
  if !this.edwRightCantInitialized || this.edwRightCantLastAngle != angle {
    let feature = new EDWAnimFeature_RightCant();
    feature.angle = angle;
    AnimationControllerComponent.ApplyFeature(this, n"EDWRightCant", feature);
    this.edwRightCantLastAngle = angle;
    this.edwRightCantInitialized = true;
  }
}

@addMethod(PlayerPuppet)
public final func EDWGetRightCantAngle() -> Float {
  return this.edwRightCantLastAngle;
}
