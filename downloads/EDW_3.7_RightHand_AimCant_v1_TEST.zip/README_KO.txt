﻿Expanded Dual Wielding 3.7 — 오른손 조준 기울기 패치 v1 TEST

첨부된 EDW 3.7을 바탕으로 만든 추가 패치입니다. 원본 모드가 설치되어 있어야 합니다.

기능
- 양손에 원거리 무기가 있고 오른손이 권총/리볼버가 아닐 때, 오른손 조준(ADS) 분기에
  손목과 총이 함께 기울어지도록 회전 노드를 추가했습니다. 기본 각도는 45도입니다.
- SMG, AR/라이플, 경기관총/중기관총, 정밀소총/저격총, 산탄총을 대상으로 합니다.
- 오른손 권총/리볼버에는 추가 회전을 적용하지 않습니다. 왼손 포즈는 원본 그대로입니다.
- 단일 무기, 근접+총 혼합 조합, 사이버웨어, 메뉴/차량 등 EDW 포즈가 비활성인 상황은 제외합니다.
- 무기 종류/성능/총알/재장전 애니메이션 파일은 바꾸지 않았습니다.

설치
1. 게임을 완전히 종료합니다. 기존 Expanded Dual Wielding 3.7은 유지합니다.
2. 이 ZIP의 archive, bin, r6 폴더를 Cyberpunk 2077 설치 폴더에 풀어 넣습니다.
3. archive/pc/mod/!!!!_EDW_RightHand_AimCant_v1_TEST.archive 파일명 앞의 !!!!를 유지하세요.
4. 게임을 시작한 뒤 양손 SMG 또는 AR을 장착하고 조준합니다.
   EDW 설정에서 해당 총기의 양손 사용이 허용되어 있어야 합니다.
5. CET 오버레이를 열면 EDW Right-hand Aim Cant 창이 나옵니다.
   기본 45도에서 왼손과 비교하여 각도를 맞추세요. 범위는 -60~60도입니다.
   필요한 경우 Reverse direction으로 기울기 방향을 바꿀 수 있습니다.
   0도 또는 체크 해제는 추가 기울기를 끕니다. 설정은 자동 저장됩니다.

CET 콘솔
GetMod("EDWRightCant").status()
  requested: 설정한 각도 / effective: 현재 장착 조합에 대해 스크립트가 전달한 각도.
  effective가 0이면 대상 조합이 아니거나 EDW 포즈 조건이 꺼진 상태입니다.
  이 값만으로 그래프 파일의 우선 적용이나 시각 결과를 증명하지는 않습니다.
GetMod("EDWRightCant").angle(30)
  각도를 30도로 조절합니다. angle(-45)는 반대 방향입니다.
GetMod("EDWRightCant").enable(false)
  추가 회전만 비활성화합니다.

검증과 한계
- 공식 WolvenKit 8.18.0 Linux 콘솔로 추출/JSON 변환/수정/재패킹/재추출했습니다.
- 재추출한 그래프는 패킹 입력과 바이트 단위로 같습니다.
- 추가 노드 2개와 오른손 ADS 입력 연결/노드 등록/기능 항목 외에 원본 그래프 필드가
  모두 보존되는 것을 WolvenKit 왕복 변환 후 구조 비교로 검증했습니다.
- CET Lua 문법과 설정/범위/활성화/저장/종료 테스트를 통과했습니다.
- 실제 게임 로딩, redscript 컴파일, 남/녀 V 및 모든 총기의 촉감/자세/간섭은 미검증입니다.
- 왼손 애니메이션을 수학적으로 복제한 파일이 아니라, 오른손 ADS에 회전을 추가한
  테스트 패치입니다. 왼손과 정확한 시각적 대칭은 게임에서 비교하여 확인해야 합니다.
- 긴 총기와 부착물은 기존 조준 위치에 따라 간섭이 생길 수 있습니다.
- player_dualwield.animgraph를 바꾸는 다른 패치와는 동시에 적용되지 않을 수 있습니다.
  EDW를 3.7 이후 버전으로 업데이트할 때는 이 패치를 먼저 제거하세요.

삭제/복구
게임 종료 후 다음 세 경로를 제거하면 원본 모드로 돌아갑니다.
archive/pc/mod/!!!!_EDW_RightHand_AimCant_v1_TEST.archive
r6/scripts/EDWRightCant/
bin/x64/plugins/cyber_engine_tweaks/mods/EDWRightCant/
원본 ExpandedDualWielding 파일은 삭제하거나 덮어쓰지 않았습니다.

도구 및 자료
WolvenKit 8.18.0: https://github.com/WolvenKit/WolvenKit/releases/tag/8.18.0
뼈대 계층 참고: WolvenKit/Cyberpunk-Blender-add-on 공개 man_base_full.glb.
공개 자료의 WeaponRight가 RightHand의 자식임을 확인하여 손과 총이 함께 움직이는
방식을 선택했습니다. 실제 플레이어 뼈대의 최종 동작은 게임 내 검증이 필요합니다.
첨부 WolvenKit ZIP은 32MiB 전송 제한으로 열지 못해, 공식 동일 버전 도구를 SHA-256
검증 후 사용했습니다. 패치의 스크립트/Lua 소스는 설치 파일 안에 그대로 들어 있습니다.
