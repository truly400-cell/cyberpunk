﻿ELIZABETH Bob003 Black — 홀로콜 헤어 전용 패치 v5 (ArchiveXL)

이전 v4의 가시성·LOD 변경으로는 사용자의 홀로콜 입 움직임 문제가 해결되지 않았습니다.
v5는 게임 원본 얼굴·표정 설정을 유지하고, ArchiveXL로 Elizabeth의 헤어 부분만 교체하는 다른 방식입니다.
실제 게임의 성공 여부는 아직 검증되지 않았습니다.

필수 구성
- ArchiveXL과 호환되는 RED4ext가 설치되어 있어야 합니다.
- 패치 문법과 컴포넌트 병합 동작은 ArchiveXL 1.28.2 소스 및 공식 문서로 확인했습니다.
- ArchiveXL 구버전을 쓰고 있다면 게임 버전에 맞는 최신 호환 버전을 사용하세요.

설치
1. 게임을 완전히 종료합니다.
2. archive/pc/mod의 기존 Elizabeth 헤어 모드 v3, v4 및 다른 이전 버전을 게임 폴더 밖으로 옮깁니다.
3. ZIP 안의 archive 폴더를 Cyberpunk 2077 게임 설치 폴더에 풀어 넣습니다.
4. archive/pc/mod에 다음 두 파일이 함께 있는지 확인합니다.
   !!!!!_ELIZABETH_Bob003_Black_HOLOCALL_v5.archive
   !!!!!_ELIZABETH_Bob003_Black_HOLOCALL_v5.archive.xl
   .archive.xl 파일도 반드시 함께 설치해야 합니다.
5. 게임을 새로 실행하고 같은 홀로콜 직전 저장 파일로 테스트합니다.

이번 변경
- 기존의 base/characters/appearances/main_npc/elizabeth_peralez.app 전체 덮어쓰기를 제거했습니다.
- default와 incognito 외형의 헤어 컴포넌트 5개씩만 별도 패치합니다.
- 얼굴 리그, 얼굴 메시, 표정 애니메이션, 의상 및 VisualController를 패치에 넣지 않았습니다.
- 검정 Bob003 헤어, 기존 NO_ROD 처리 등 나머지 38개 리소스는 원본과 바이트 단위로 같습니다.
- 필요한 헤어 의존성만 추가하고, 원본 얼굴 의존성은 교체하지 않습니다.
- v4의 얼굴 가시성·LOD 강제 변경은 포함하지 않았습니다.

검사한 범위
- WolvenKit으로 새 패치를 생성하고 아카이브 전체 39개 리소스를 다시 추출했습니다.
- 69개 세그먼트 압축 해제, 아카이브 인덱스 CRC64, 패치의 컴포넌트 ID/핸들/의존성 및 ZIP 무결성을 확인했습니다.
- 게임 실행과 홀로콜 동작은 여기서 검사하지 못했습니다.
- 설치 후 새 헤어가 보이지 않으면 두 파일의 배치와 ArchiveXL 작동/버전을 먼저 확인하세요.

되돌리기
v5의 .archive와 .archive.xl 두 파일을 모두 제거하세요. 기존 버전을 다시 쓸 경우 하나만 복원하세요.
