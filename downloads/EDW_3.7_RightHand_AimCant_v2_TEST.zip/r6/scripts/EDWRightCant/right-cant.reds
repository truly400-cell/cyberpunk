// Expanded Dual Wielding 3.7 add-on: only the graph's right ADS branch reads this feature.
public class EDWAnimFeature_RightCant extends AnimFeature {
  public let angle: Float;
}

@addField(PlayerPuppet)
private let edwRightCantInitialized: Bool;
@addField(PlayerPuppet)
private let edwRightCantLastAngle: Float;
@addField(PlayerPuppet)
private let edwRightCantLastReason: String;

// This is a pose add-on, independent of EDW's optional independent-input switch.
// EDWInput.PoseContext requires edwEnabled, which is false in the default controls.
@addMethod(PlayerPuppet)
private final func EDWRightCantContextReason() -> String {
  if !this.IsControlledByLocalPeer() { return "not_local_player"; }
  let ui = GameInstance.GetBlackboardSystem(this.GetGame()).Get(GetAllBlackboardDefs().UI_System);
  if ui.GetBool(GetAllBlackboardDefs().UI_System.IsInMenu) { return "menu"; }
  let bb = GameInstance.GetBlackboardSystem(this.GetGame()).GetLocalInstanced(this.GetEntityID(), GetAllBlackboardDefs().PlayerStateMachine);
  if bb.GetInt(GetAllBlackboardDefs().PlayerStateMachine.Vehicle) != 0 { return "vehicle"; }
  if bb.GetInt(GetAllBlackboardDefs().PlayerStateMachine.SceneTier) > 2 { return "scene"; }
  if bb.GetInt(GetAllBlackboardDefs().PlayerStateMachine.Vitals) != 0 { return "not_alive"; }
  let right = GameObject.GetRightActiveWeapon(this);
  let left = GameObject.GetLeftActiveWeapon(this);
  if !IsDefined(right) || !IsDefined(left) { return "two_weapons_required"; }
  if !WeaponObject.IsRanged(right.GetItemID()) || !WeaponObject.IsRanged(left.GetItemID()) {
    return "two_ranged_weapons_required";
  }
  if right.WeaponHasTag(n"Cyberware") || left.WeaponHasTag(n"Cyberware") { return "cyberware"; }
  let record = right.GetWeaponRecord();
  if !IsDefined(record) || !IsDefined(record.ItemType()) { return "missing_weapon_record"; }
  let weaponType = record.ItemType().Type();
  if Equals(weaponType, gamedataItemType.Wea_Handgun) || Equals(weaponType, gamedataItemType.Wea_Revolver) {
    return "pistol_pose_preserved";
  }
  return "active";
}

@addMethod(PlayerPuppet)
public final func EDWConfigureRightCant(requestedAngle: Float) -> Void {
  let angle = 0.0;
  let reason = this.EDWRightCantContextReason();
  if Equals(reason, "active") {
    angle = ClampF(requestedAngle, -60.0, 60.0);
    if angle == 0.0 { reason = "zero_angle_or_disabled"; }
  }
  this.edwRightCantLastReason = reason;
  if !this.edwRightCantInitialized || this.edwRightCantLastAngle != angle {
    let feature = new EDWAnimFeature_RightCant();
    feature.angle = angle;
    AnimationControllerComponent.ApplyFeature(this, n"EDWRightCant", feature);
    this.edwRightCantLastAngle = angle;
    this.edwRightCantInitialized = true;
  }
}

@addMethod(PlayerPuppet)
public final func EDWGetRightCantAngle() -> Float {
  return this.edwRightCantLastAngle;
}

@addMethod(PlayerPuppet)
public final func EDWGetRightCantReason() -> String {
  return this.edwRightCantLastReason;
}
