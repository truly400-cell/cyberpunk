﻿EDW 3.7 오른손 조준 기울기 패치 — v2 TEST

v1 수정
- EDWInput.PoseContext의 edwEnabled 조건은 독립 조작 옵션을 요구했습니다.
  원본 EDW3.7은 독립 조작이 기본 OFF여서 일반 쌍수에서도 각도가0이 될 수 있었습니다.
  v2는 이 입력 옵션에 의존하지 않는 별도 쌍수/게임 상태 판정으로 바꿨습니다.
- EDWRightCant 기능을 상위 player_base 그래프에도 등록했습니다.
- 상태에 reason을 추가하고 CET 오버레이 중에는 게임 상태를 덮어쓰지 않습니다.
  각도 변경은 CET를 닫은 다음 게임 업데이트에서 적용됩니다.

교체 설치
1. 게임을 완전히 종료합니다. CET의 Reload all mods만으로는 redscript를 교체할 수 없습니다.
2. 원본 Expanded Dual Wielding 3.7은 계속 켜둡니다.
3. 모드 매니저라면 v1 기울기 패치를 끄고 이 v2 패치를 켭니다.
   수동 설치라면 ZIP의 archive/bin/r6를 게임 폴더에 풀어 같은 경로에 덮어씁니다.
   archive 파일은 v1과 같은 이름을 일부러 유지하여 중복 패치가 남지 않게 했습니다:
   archive/pc/mod/!!!!_EDW_RightHand_AimCant_v1_TEST.archive
   파일명에 v1이 있어도 이 ZIP 안의 내용은 v2입니다. 앞의 !!!!를 유지하세요.
4. 게임을 시작하고 양손 SMG/AR/산탄총 등 대상 무기를 장착합니다.
5. CET EDW Right-hand Aim Cant 창에서 Enable 체크 및45도를 확인하고 CET를 닫습니다.
6. 조준 자세를 확인합니다. 각도는 -60~60도, 반대 방향은 Reverse direction입니다.
   권총/리볼버와 왼손은 원본 포즈를 유지하며 단일 무기/근접 혼합 조합은 제외합니다.
   기본45도가 왼손과 맞는지는 게임에서 확인하고 조절해야 합니다.

진단
조준을 시도한 뒤 CET 콘솔에서 다음을 실행합니다:
GetMod("EDWRightCant").status()

v2에서는 [EDWRightCant v2]와 reason이 함께 나옵니다.
requested=45 effective=45 reason=active: 스크립트가45도를 전달한 상태입니다.
이 값만으로 archive 로드 우선순위나 실제 손 회전까지 증명하지는 않습니다.
reason=pistol_pose_preserved: 오른손이 권총/리볼버여서 추가 회전 제외.
reason=two_weapons_required / two_ranged_weapons_required: 대상 쌍수 조합이 아님.
reason=menu / vehicle / scene / not_alive: 해당 게임 상태 때문에 제외.
reason=zero_angle_or_disabled: 추가 기울기 설정이0 또는OFF.
reason=script_v1_or_unavailable: Lua만 갱신되고 새 redscript가 반영되지 않았을 수 있음.
error가 있으면 그 문구와 전체 상태 결과를 확인하세요.

GetMod("EDWRightCant").angle(30)
  각도30도로 설정. CET를 닫으면 반영됩니다.
GetMod("EDWRightCant").enable(false)
  추가 기울기를 끕니다. CET를 닫으면 반영됩니다.

검증 및 제한
WolvenKit8.18.0 재패킹/재추출로 그래프2개를 검사했습니다.
두 그래프 모두 패킹 입력과 재추출 파일이 바이트 단위로 같습니다.
상위 player_base는 새 기능 등록 외 원본 EDW3.7의 모든Data 필드가 보존됩니다.
하위 player_dualwield의 v1 회전 노드/오른손ADS연결과 원본 필드 보존도 유지했습니다.
CET Lua 문법/설정/활성화/각도 범위/저장/오버레이 중 적용 보류/종료 검사를 통과했습니다.
redscript 게임 내 컴파일과 실제 플레이어 자세는 이 환경에서 검증하지 못했습니다.
왼손 클립 자체를 미러 복제한 방식이 아니라 오른손ADS 손목 회전 추가 방식입니다.
이 v2의 실기 동작과 정확한 좌우 대칭은 아직 미검증입니다.

삭제/복구
게임 종료 후 아래 새 패치 경로만 제거합니다. 원본 EDW3.7은 지우지 않습니다.
archive/pc/mod/!!!!_EDW_RightHand_AimCant_v1_TEST.archive
r6/scripts/EDWRightCant/
bin/x64/plugins/cyber_engine_tweaks/mods/EDWRightCant/

EDW3.7 전용입니다. 이후 EDW업데이트 시 이 패치를 먼저 제거하세요.
설치한 다른 모드가 player_base 또는 player_dualwield 그래프를 덮어쓰면 충돌할 수 있습니다.
도구: 공식 WolvenKit8.18.0 ConsoleLinux (배포SHA256 검증).
세부 변경과 무결성 값은 validation-report.json / patch-design.json / SHA256SUMS.txt에 있습니다.
