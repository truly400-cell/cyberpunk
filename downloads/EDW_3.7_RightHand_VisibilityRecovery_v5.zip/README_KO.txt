EDW3.7 v5 오른쪽 무기 소실 복구본

v4 사용 중지
사용자 게임에서 v4의 오른쪽 무기 소실/팔이 카메라 앞으로 이동하는 오류가 확인됐습니다.
참조 뼈대의 수학 계산과 WolvenKit 변환 성공만으로 실제 플레이어 포즈를 검증하지 못했습니다.
v5는 v4의 위치/회전 복사와 LS/MS 변환, 임시 위치 트랙을 모두 제거합니다.
아카이브는 사용자가 오른쪽 무기를 볼 수 있었던 v3와 바이트 단위로 동일합니다.
오른손45도 기울기만 복구하며 양손 위치의 완전한 대칭 정렬은 아직 해결되지 않았습니다.
원본 좌우 위치 차이를 해결한 버전이라고 안내하지 않습니다.

설치
1. 게임을 완전히 종료합니다.
2. 원본 Expanded Dual Wielding3.7은 켜둡니다.
3. 이전 v1~v4 패치를 모두 끄고 이 v5만 켭니다.
   수동 설치는 ZIP의 archive/bin/r6를 게임 설치 폴더 같은 경로에 덮어씁니다.
   내부 archive 파일명은 이전과 같으며 내용은 v3 그래프로 복원된 v5입니다.
   !!!!_EDW_RightHand_AimCant_v1_TEST.archive 이름을 임의로 바꾸지 마세요.
4. CET 창 이름은 EDW Right-hand Cant v5 Recovery입니다.
   Enable right-hand cant while aiming을 켜고 Extra roll trim=0으로 둡니다.
   v4에서 Match를 껐다면 설정OFF가 보존되므로 v5 Enable을 다시 켜야 합니다.
5. CET를 닫고 양손 원거리 무기로 LT 조준합니다.
   오른손 권총/리볼버와 제외 상황은 원본 포즈를 유지합니다.
   Reload all mods만으로 새 그래프/redscript가 교체되지는 않습니다.

설정/진단
Extra roll trim=0은 실제 기본 기울기45도입니다. 추가 보정만0인 것입니다.
기능을 끄면 기울기도 해제됩니다. 기존 schema4 설정의 활성화 여부/추가 보정은 유지됩니다.
GetMod("EDWRightCant").status()에서 [EDWRightCant v5]를 확인합니다.
weight=1은 활성 요청, effectiveAngle은 스크립트가 요청한 최종 각도입니다.
Test pose for 3s after closing CET 버튼은 CET를 닫은 뒤3초간 기울기를 요청합니다.

종료 처리
v4에서 추가했던 종료 안전성 수정은 유지합니다.
플레이어 객체를 저장하지 않고 숫자/문자열 상태만 저장합니다.
플레이어 OnDetach 전에 업데이트를 차단하며 onShutdown은 Lua 상태만 정리합니다.
종료 시 네이티브/게임 API/강제 GC를 호출하지 않습니다.
보내준 종료 로그만으로 EDW가 단일 원인인지, 실제 종료 크래시가 없어졌는지 확정할 수 없습니다.

검증
아카이브와 v3의 바이트 일치, ZIP/체크섬 일치, CET 설정 테스트와7개 종료/분리 테스트 통과.
실제 게임에서 v5 무기 표시/redscript 컴파일/종료는 이 환경에서 검증하지 못했습니다.
정확한 좌우 정렬은 미해결입니다. 상세 결과는 validation-report.json에 있습니다.

원본 상태로 제거
게임 종료 후 아래 패치 경로만 지우고 원본 EDW3.7은 유지합니다.
archive/pc/mod/!!!!_EDW_RightHand_AimCant_v1_TEST.archive
r6/scripts/EDWRightCant/
bin/x64/plugins/cyber_engine_tweaks/mods/EDWRightCant/
