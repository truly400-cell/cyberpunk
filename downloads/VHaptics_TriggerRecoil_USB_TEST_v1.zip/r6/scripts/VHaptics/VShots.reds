// Grunhart V Haptics - each shot V fires, the moment the game kicks the crosshair for it
// (UI_ActiveWeaponData.ShootEvent), with the weapon's kind, line (power / tech / smart), recoil kick and charge.
// The CET half (GrunhartHaptics) takes the queue every frame and turns each shot into a recoil on the hands.
module GrunhartHaptics

public class GrunhartVShots extends ScriptableSystem {
  private let m_queue: array<String>;
  private let m_shootCb: ref<CallbackHandle>;
  private let m_shots: Int32;
  private let m_magR: Int32;
  private let m_magL: Int32;
  private let m_lastHand: String;

  private func Mag(w: ref<WeaponObject>) -> Int32 {
    if !IsDefined(w) { return -1; }
    return Cast<Int32>(WeaponObject.GetMagazineAmmoCount(w));
  }

  private func OnAttach() -> Void {
    let bb = GameInstance.GetBlackboardSystem(this.GetGameInstance()).Get(GetAllBlackboardDefs().UI_ActiveWeaponData);
    this.m_shootCb = bb.RegisterListenerVariant(GetAllBlackboardDefs().UI_ActiveWeaponData.ShootEvent, this, n"OnShoot");
  }

  protected cb func OnShoot(arg: Variant) -> Bool {
    let game = this.GetGameInstance();
    let player = GetPlayer(game);
    if !IsDefined(player) { return false; }
    let ts = GameInstance.GetTransactionSystem(game);
    let w = ts.GetItemInSlot(player, t"AttachmentSlots.WeaponRight") as WeaponObject;
    if !IsDefined(w) { return false; }
    // akimbo: which hand fired - the one whose magazine went down (both: both); not yet down: the other hand from last time
    let hand = "R";
    let dual = player.GetPlayerStateMachineBlackboard().GetBool(GetAllBlackboardDefs().PlayerStateMachine.IsDualWielding);
    let wl = ts.GetItemInSlot(player, t"AttachmentSlots.WeaponLeft") as WeaponObject;
    if dual && IsDefined(wl) && wl != w {
      let magR = this.Mag(w);
      let magL = this.Mag(wl);
      let downR = magR < this.m_magR;
      let downL = magL < this.m_magL;
      if downR && downL {
        hand = "B";
      } else if downL {
        hand = "L";
      } else if downR {
        hand = "R";
      } else if Equals(this.m_lastHand, "R") {
        hand = "L";
      }
      this.m_magR = magR;
      this.m_magL = magL;
      if Equals(hand, "L") { w = wl; }
    }
    this.m_lastHand = hand;
    let id = ItemID.GetTDBID(w.GetItemID());
    let rec = TweakDBInterface.GetWeaponItemRecord(id);
    let kind = "?";
    let evo = "?";
    let maker = "?";
    let label = "?";
    if IsDefined(rec) {
      if IsDefined(rec.ItemType()) { kind = TDBID.ToStringDEBUG(rec.ItemType().GetID()); }
      if IsDefined(rec.Evolution()) { evo = TDBID.ToStringDEBUG(rec.Evolution().GetID()); }
      if IsDefined(rec.Manufacturer()) { maker = TDBID.ToStringDEBUG(rec.Manufacturer().GetID()); }
      label = GetLocalizedTextByKey(rec.DisplayName());
    }
    let trigger = "?";
    let tm = w.GetCurrentTriggerMode();
    if IsDefined(tm) { trigger = TDBID.ToStringDEBUG(tm.GetID()); }
    let obj = Cast<StatsObjectID>(w.GetEntityID());
    let stats = GameInstance.GetStatsSystem(game);
    let kick = stats.GetStatValue(obj, gamedataStatType.RecoilKickMax);
    let pellets = stats.GetStatValue(obj, gamedataStatType.ProjectilesPerShot);
    let cycle = stats.GetStatValue(obj, gamedataStatType.CycleTime);
    let charge = GameInstance.GetStatPoolsSystem(game).GetStatPoolValue(obj, gamedataStatPoolType.WeaponCharge, false);
    let upper = player.GetPlayerStateMachineBlackboard().GetInt(GetAllBlackboardDefs().PlayerStateMachine.UpperBody);
    let sil = "0";
    if w.IsSilenced() { sil = "1"; }
    // built-in suppressors (iconics like Overwatch): their own suppressed gun sound set
    if IsDefined(rec) && (StrContains(NameToString(rec.AudioName()), "suppressor") || StrContains(NameToString(rec.AudioName()), "grad_panam")) { sil = "1"; }
    this.m_shots += 1;
    if ArraySize(this.m_queue) < 64 {
      ArrayPush(this.m_queue, kind + "|" + evo + "|" + FloatToStringPrec(kick, 3) + "|" + FloatToStringPrec(charge, 1)
        + "|" + FloatToStringPrec(pellets, 0) + "|" + IntToString(upper) + "|" + TDBID.ToStringDEBUG(id) + "|" + hand
        + "|" + trigger + "|" + FloatToStringPrec(cycle, 3) + "|" + maker + "|" + label + "|" + sil);
    }
    return true;
  }

  public func Take() -> array<String> {
    let out = this.m_queue;
    ArrayClear(this.m_queue);
    return out;
  }

  public func Shots() -> Int32 { return this.m_shots; }
}
