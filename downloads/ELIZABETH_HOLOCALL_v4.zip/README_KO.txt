﻿ELIZABETH Bob003 Black — 홀로콜 얼굴 애니메이션 테스트 수정본 v4

설치
1. 게임을 완전히 종료합니다.
2. archive/pc/mod 폴더에 설치된 기존 !!!!!_ELIZABETH_Bob003_Black_FIXED_v3_NO_ROD_SAFE.archive를 게임 폴더 밖에 백업합니다.
   같은 Elizabeth 헤어 모드의 구버전 아카이브를 동시에 설치하지 마세요.
3. 이 ZIP의 archive 폴더를 Cyberpunk 2077 게임 설치 폴더에 풀어 넣습니다.
4. 게임을 다시 실행하고, 문제의 홀로콜 직전 저장 파일을 불러와 통화를 확인합니다.

변경 사항
Elizabeth의 default와 incognito 외형에서 face_rig의 다음 값만 변경했습니다.
- clientForcedLod: -1 → 0
- clientForcedVisibility: 0 → 1
- useLongRangeVisibility: 0 → 1
얼굴 애니메이션의 가시성/LOD 갱신을 강제로 유지하는 우회 수정입니다.
헤어 모양·검정색 재질·기존 NO_ROD 리소스와 다른 38개 리소스는 원본과 동일합니다.

검증 범위
WolvenKit으로 재변환·패킹·재추출을 검사했습니다.
얼굴 리그, 표정 그래프, facialsetup, 애니메이션 연결 및 컴포넌트 ID는 유지했습니다.
원본에 명백히 깨진 얼굴 연결은 발견되지 않아, 원인을 확정한 수정은 아닙니다.
실제 게임과 홀로콜은 이 환경에서 실행하지 못했습니다. 해결 여부는 게임에서 확인이 필요합니다.
얼굴 리그를 강제로 활성화하므로 Elizabeth가 로드된 동안 애니메이션 처리량이 증가할 수 있습니다.

되돌리기
이 v4 아카이브를 제거하고 백업한 기존 v3 아카이브를 복원하세요.
