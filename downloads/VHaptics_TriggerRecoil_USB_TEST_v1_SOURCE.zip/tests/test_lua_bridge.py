"""Requires lupa (Lua runtime). Run from any directory; no game or controller."""
from pathlib import Path
from lupa import LuaRuntime

ROOT = Path(__file__).resolve().parents[1]
MOD = ROOT / 'package/bin/x64/plugins/cyber_engine_tweaks/mods/VHaptics'
lua = LuaRuntime(unpack_returned_tuples=True)
for path in MOD.rglob('*.lua'):
    lua.execute('assert(load(...))', path.read_text())
print('PASS: all packaged Lua files compile')

lua.execute('''
writes = {}
io.open = function(path, mode)
  assert(path == "triggers-state.txt" and mode == "w")
  return { write = function(self, text) table.insert(writes, text) return self end,
           close = function() end }
end
paused, menu, hasPlayer = false, false, true
Game = {
 GetPlayer = function() if hasPlayer then return {} end end,
 GetTimeSystem = function() return { IsPausedState = function() return paused end } end,
 GetAllBlackboardDefs = function() return { UI_System = { IsInMenu = "menu" } } end,
 GetBlackboardSystem = function() return {
   Get = function() return { GetBool = function() return menu end } end } end,
}
''')
triggers = lua.execute((MOD / 'modules/triggers.lua').read_text())
lua.globals().triggers = triggers
lua.execute('''
local function latest() return writes[#writes] end
triggers.init()
assert(latest():find("seq=0 ",1,true) and latest():find("active=0",1,true))
triggers.update(0.1)
assert(latest():find("active=1",1,true))
triggers.shot("SubmachineGun", "R", 0.075, 1)
assert(latest():find("seq=1 ",1,true) and latest():find("cycle=0.0750",1,true))
local fired = latest()
triggers.update(0.1)
assert(latest():find("seq=1 ",1,true) and latest() ~= fired) -- heartbeat only
triggers.shot("LightMachineGun", "B", 0.09, 1.2)
assert(latest():find("seq=2 ",1,true) and latest():find("hand=B",1,true))
menu = true
triggers.update(0)
assert(latest():find("active=0",1,true))
menu, paused = false, true
triggers.update(0.1)
assert(latest():find("active=0",1,true))
paused, hasPlayer = false, false
triggers.update(0.1)
assert(latest():find("active=0",1,true))
triggers.update(0.1)
triggers.shot("SubmachineGun", "R", 0.075, 1)
triggers.shot("SubmachineGun", "L", 0.075, 1)
assert(latest():find("hand=B",1,true))
triggers.shutdown()
assert(latest():find("active=0",1,true))
''')
print('PASS: Lua baseline, per-shot sequence, heartbeat, both-hand, menu/pause/player loss/shutdown')

# Execute the actual patched onShot body with minimal game-independent mocks.
source = (MOD / 'modules/events.lua').read_text()
body = source.split('local function onShot(rec)', 1)[1].split('-- ------------------------------------------------------------------------------------------------ V', 1)[0]
lua.execute('''
GUN={on=true,seen={},peak={},gain=1,charge={},shots=0}
KICKREF={SubmachineGun=1}
MIDKICK={}
gunName={}
baseKick=function() return nil end
exeRunning, bodyShots, triggerShots = true, 0, 0
exeAlive=function() return exeRunning end
hand=function() bodyShots=bodyShots+1 end
play=function() end
S={}
triggerRecoil={shot=function(kind, hand, cycle, power)
 assert(kind=="SubmachineGun" and hand=="R" and cycle==0.075)
 triggerShots=triggerShots+1
end}
''')
lua.execute('onShot = function(rec)' + body)
record = 'ItemType.Wea_SubmachineGun|WeaponEvolution.Power|0.57|0|1|0|Items.Test|R|TriggerMode.FullAuto|0.075|WeaponManufacturer.Test|Test|0'
lua.globals().GUN.seen['Items.Test'] = True
lua.globals().onShot(record)
lua.globals().exeRunning = False
lua.globals().onShot(record)
lua.execute('assert(bodyShots==1 and triggerShots==2 and GUN.shots==2)')
print('PASS: actual onShot preserves original output and mirrors shots with audio helper running or absent')
