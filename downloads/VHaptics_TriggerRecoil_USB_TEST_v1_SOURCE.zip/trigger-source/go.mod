module vhapticstriggers

go 1.22
