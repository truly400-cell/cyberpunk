package main

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestINIClampAndReject(t *testing.T) {
	path := filepath.Join(t.TempDir(), "triggers.ini")
	c, on, err := loadSettings(path)
	if err != nil || !on || c != DefaultConfig() {
		t.Fatalf("defaults: %+v %v %v", c, on, err)
	}
	os.WriteFile(path, []byte("; comment\nstart=99\nstrength=-7\nheavystrength=99 # clamp\nenabled=0\n"), 0600)
	c, on, err = loadSettings(path)
	if err != nil || on || c.Start != 9 || c.Strength != 1 || c.HeavyStrength != 8 {
		t.Fatalf("bounds: %+v %v %v", c, on, err)
	}
	for _, txt := range []string{"strength=oops", "enable=1", "broken"} {
		os.WriteFile(path, []byte(txt), 0600)
		if _, _, err = loadSettings(path); err == nil {
			t.Fatalf("accepted malformed INI: %s", txt)
		}
	}
}

func TestFreshSnapshotsNeverReplayUnchangedOrOldFile(t *testing.T) {
	path := filepath.Join(t.TempDir(), "state.txt")
	now := time.Now().Round(time.Millisecond)
	text := []byte("version=1 session=test seq=1 active=1 hand=R kind=SubmachineGun cycle=0.08 power=1 tick=1\n")
	put := func(b []byte, when time.Time) {
		t.Helper()
		if e := os.WriteFile(path, b, 0600); e != nil {
			t.Fatal(e)
		}
		if e := os.Chtimes(path, when, when); e != nil {
			t.Fatal(e)
		}
	}
	put(text, now)
	snapshot, data, when, ok := readFreshSnapshot(path, now, nil, 350*time.Millisecond)
	if !ok || snapshot.Seq != 1 || !bytes.Equal(data, text) || !when.Equal(now) {
		t.Fatalf("fresh result %+v %v %v", snapshot, when, ok)
	}
	// Rewriting/touching the exact same bytes is not a heartbeat.
	put(text, now.Add(time.Millisecond))
	if _, _, _, ok = readFreshSnapshot(path, now.Add(time.Millisecond), text, 350*time.Millisecond); ok {
		t.Fatal("unchanged content became heartbeat")
	}
	// Newly observed bytes from a stale file do not become fresh on read.
	put(text, now.Add(-351*time.Millisecond))
	if _, _, _, ok = readFreshSnapshot(path, now, nil, 350*time.Millisecond); ok {
		t.Fatal("stale file accepted")
	}
	// A changing tick allows a heartbeat without duplicating a shot sequence.
	heartbeat := bytes.Replace(text, []byte("tick=1"), []byte("tick=2"), 1)
	put(heartbeat, now)
	if _, _, _, ok = readFreshSnapshot(path, now, text, 350*time.Millisecond); !ok {
		t.Fatal("new tick rejected")
	}
	put([]byte("version=1 session=test seq=2 active=1"), now)
	if _, _, _, ok = readFreshSnapshot(path, now, text, 350*time.Millisecond); ok {
		t.Fatal("partial write accepted")
	}
	// Even all numeric fields may be an unfinished write until the terminating newline.
	put(bytes.TrimSuffix(text, []byte("\n")), now)
	if _, _, _, ok = readFreshSnapshot(path, now, nil, 350*time.Millisecond); ok {
		t.Fatal("unterminated snapshot accepted")
	}
	put(text, now.Add(2*time.Second))
	if _, _, _, ok = readFreshSnapshot(path, now, nil, 350*time.Millisecond); ok {
		t.Fatal("future file accepted")
	}
}

func TestDelayedSnapshotUsesOriginalWriteTime(t *testing.T) {
	path := filepath.Join(t.TempDir(), "state.txt")
	now := time.Now().Round(time.Millisecond)
	baseline := []byte("version=1 session=test seq=0 active=1 hand=R kind=SubmachineGun cycle=0.08 power=1 tick=1\n")
	shot := []byte("version=1 session=test seq=1 active=1 hand=R kind=SubmachineGun cycle=0.08 power=1 tick=2\n")
	c := NewController(DefaultConfig())
	b, _ := ParseSnapshot(baseline)
	c.ProcessSnapshot(now.Add(-300*time.Millisecond), b)
	os.WriteFile(path, shot, 0600)
	written := now.Add(-200 * time.Millisecond)
	os.Chtimes(path, written, written)
	s, _, when, ok := readFreshSnapshot(path, now, baseline, 350*time.Millisecond)
	if !ok {
		t.Fatal("fresh-but-delayed file rejected")
	}
	c.ProcessSnapshot(when, s)
	l, r := c.Effects(now)
	if l != EffectOff() || r != EffectOff() {
		t.Fatal("delayed read replayed expired shot")
	}
}
