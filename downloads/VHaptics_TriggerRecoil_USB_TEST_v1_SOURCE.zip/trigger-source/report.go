package main

// makeUSBReport updates right R2 and only updates left L2 when needed, so an
// inactive left effect never needlessly overwrites the aiming trigger. The
// game/native trigger writer still must be disabled: HID outputs have no mixer.
func makeUSBReport(size int, left, right TriggerEffect, leftOwned bool) ([]byte, bool) {
	if size < 48 || size > 65 {
		return nil, leftOwned
	}
	report := make([]byte, size)
	report[0], report[1] = 0x02, 0x04
	copy(report[11:22], right[:])
	nextLeftOwned := left != EffectOff()
	if nextLeftOwned || leftOwned {
		report[1] |= 0x08
		copy(report[22:33], left[:])
	}
	return report, nextLeftOwned
}
