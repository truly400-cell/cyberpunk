//go:build windows

package main

import (
	"fmt"
	"log"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"
	"time"
)

func main() {
	exe, err := os.Executable()
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	dir := filepath.Dir(exe)
	stopPath := filepath.Join(dir, "trigger-stop.flag")
	arg := ""
	if len(os.Args) > 1 {
		arg = os.Args[1]
	}
	if len(os.Args) > 2 || (arg != "" && arg != "--test" && arg != "--stop" && arg != "--help") {
		fmt.Fprintln(os.Stderr, "Usage: VHapticsTriggers.exe [--test | --stop | --help]")
		os.Exit(1)
	}
	if arg == "--help" {
		fmt.Println("VHaptics USB DualSense/Edge trigger vibration helper. Run beside triggers.ini. --test: 2-second R2 test; --stop: stop running helper. No DSX required; disable game native adaptive triggers and other HID trigger writers.")
		return
	}
	if arg == "--stop" {
		if err := os.WriteFile(stopPath, []byte("stop\n"), 0600); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		fmt.Println("Stop requested; running helper releases its triggers and exits.")
		return
	}
	logger := log.New(os.Stdout, "[VHapticsTriggers] ", log.Ldate|log.Ltime)
	file, err := os.OpenFile(filepath.Join(dir, "triggers.log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err == nil {
		defer file.Close()
		logger = log.New(file, "", log.Ldate|log.Ltime)
	}
	instance, err := acquireInstance()
	if err != nil {
		logger.Println(err)
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer syscall.CloseHandle(instance)
	os.Remove(stopPath)
	config, enabled, err := loadSettings(filepath.Join(dir, "triggers.ini"))
	if err != nil {
		logger.Println(err)
		fmt.Fprintln(os.Stderr, err)
		return
	}
	if !enabled {
		logger.Println("disabled by triggers.ini")
		return
	}
	logger.Printf("starting USB-only helper: zone %d, auto strength %d, heavy strength %d", config.Start, config.Strength, config.HeavyStrength)
	logger.Println("Disable game adaptive triggers, DSX/DS4Windows trigger effects and Steam Input to avoid competing output. Existing VHaptics.exe audio is unchanged.")
	fmt.Println("VHapticsTriggers started. Status: triggers.log. Ctrl+C or stop_triggers.bat to stop.")
	signals := make(chan os.Signal, 1)
	signal.Notify(signals, os.Interrupt, syscall.SIGTERM)
	defer signal.Stop(signals)
	var device *hidDevice
	defer func() {
		if device != nil {
			device.send(EffectOff(), EffectOff())
			device.close()
		}
	}()
	if arg == "--test" {
		device, err = openDualSenseUSB()
		if err != nil {
			logger.Println(err)
			fmt.Fprintln(os.Stderr, err)
			return
		}
		logger.Printf("test on %s: squeeze R2 past zone %d", device.name, config.Start)
		fmt.Printf("Squeeze R2 past zone %d; vibration runs for 2 seconds.\n", config.Start)
		if err := device.send(EffectOff(), EffectVibration(config.Start, config.Strength, 15)); err != nil {
			logger.Println(err)
			fmt.Fprintln(os.Stderr, err)
			return
		}
		timer := time.NewTimer(2 * time.Second)
		defer timer.Stop()
		select {
		case <-timer.C:
		case <-signals:
		}
		logger.Println("test ended; trigger released")
		return
	}
	controller := NewController(config)
	var previous []byte
	var lastLeft, lastRight TriggerEffect
	lastLeft, lastRight = EffectOff(), EffectOff()
	retry := time.Time{}
	lastReason := ""
	ticker := time.NewTicker(8 * time.Millisecond)
	defer ticker.Stop()
	for {
		select {
		case <-signals:
			logger.Println("interrupted; releasing triggers")
			return
		case now := <-ticker.C:
			if _, err := os.Stat(stopPath); err == nil {
				os.Remove(stopPath)
				logger.Println("stop requested; releasing triggers")
				return
			}
			if device == nil {
				if now.Before(retry) {
					continue
				}
				retry = now.Add(2 * time.Second)
				d, e := openDualSenseUSB()
				if e != nil {
					if e.Error() != lastReason {
						lastReason = e.Error()
						logger.Println(e)
						fmt.Fprintln(os.Stderr, e)
					}
					continue
				}
				device = d
				if e = device.send(EffectOff(), EffectOff()); e != nil {
					logger.Println(e)
					device.close()
					device = nil
					continue
				}
				logger.Printf("connected %s (output report %d bytes)", device.name, device.reportSize)
				lastReason = ""
				// A reconnect establishes a new baseline: never replay the last cached shot.
				controller = NewController(config)
				previous = nil
				lastLeft, lastRight = EffectOff(), EffectOff()
			}
			snapshot, data, when, fresh := readFreshSnapshot(filepath.Join(dir, "triggers-state.txt"), now, previous, config.Watchdog)
			if fresh {
				if controller.ProcessSnapshot(when, snapshot) {
					previous = data
				}
			}
			left, right := controller.Effects(now)
			if left != lastLeft || right != lastRight {
				if e := device.send(left, right); e != nil {
					logger.Println(e)
					device.close()
					device = nil
					continue
				}
				lastLeft, lastRight = left, right
			}
		}
	}
}
