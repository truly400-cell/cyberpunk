package main

import (
	"bytes"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

func loadSettings(path string) (Config, bool, error) {
	c := DefaultConfig()
	b, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		return c, true, nil
	}
	if err != nil {
		return c, false, err
	}
	enabled := true
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, ";") || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "[") {
			continue
		}
		pair := strings.SplitN(line, "=", 2)
		if len(pair) != 2 {
			return c, false, fmt.Errorf("invalid triggers.ini line %q", line)
		}
		key, val := strings.ToLower(strings.TrimSpace(pair[0])), strings.TrimSpace(pair[1])
		for _, sep := range []string{";", "#"} {
			val = strings.TrimSpace(strings.SplitN(val, sep, 2)[0])
		}
		n, e := strconv.Atoi(val)
		if e != nil {
			return c, false, fmt.Errorf("triggers.ini %s must be an integer", key)
		}
		switch key {
		case "enabled":
			enabled = n != 0
		case "start":
			c.Start = n
		case "strength":
			c.Strength = n
		case "heavystrength":
			c.HeavyStrength = n
		default:
			return c, false, fmt.Errorf("unknown triggers.ini key %q", key)
		}
	}
	return c.normalized(), enabled, nil
}

func readFreshSnapshot(path string, now time.Time, previous []byte, watchdog time.Duration) (Snapshot, []byte, time.Time, bool) {
	var empty Snapshot
	info, err := os.Stat(path)
	if err != nil || info.Size() > 2048 || info.Size() == 0 {
		return empty, previous, time.Time{}, false
	}
	age := now.Sub(info.ModTime())
	if age < -time.Second || age > watchdog {
		return empty, previous, time.Time{}, false
	}
	data, err := os.ReadFile(path)
	if err != nil || !bytes.HasSuffix(data, []byte("\n")) || bytes.Equal(data, previous) {
		return empty, previous, time.Time{}, false
	}
	after, err := os.Stat(path)
	if err != nil || !after.ModTime().Equal(info.ModTime()) || after.Size() != info.Size() {
		return empty, previous, time.Time{}, false
	}
	snapshot, err := ParseSnapshot(data)
	if err != nil {
		return empty, previous, time.Time{}, false
	}
	when := info.ModTime()
	if when.After(now) {
		when = now
	} // Small wall-clock skew must not extend a pulse.
	return snapshot, data, when, true
}
