package main

import (
	"encoding/binary"
	"testing"
	"time"
)

func shot(seq uint64, hand string) Snapshot {
	return Snapshot{Version: 1, Session: "test1", Seq: seq, Active: true, Hand: hand, Kind: "SubmachineGun", Cycle: 0.075, Power: 1}
}
func baseline(c *Controller, t time.Time) { c.ProcessSnapshot(t, shot(0, "R")) }

func TestEffectEncoding(t *testing.T) {
	e := EffectVibration(3, 5, 13)
	if e[0] != 0x26 || binary.LittleEndian.Uint16(e[1:3]) != 0x3f8 || e[9] != 13 || e[7] != 0 || e[8] != 0 || e[10] != 0 {
		t.Fatalf("bad encoding %x", e)
	}
	forces := binary.LittleEndian.Uint32(e[3:7])
	for zone := 0; zone < 10; zone++ {
		want := uint32(0)
		if zone >= 3 {
			want = 4
		}
		if (forces>>uint(3*zone))&7 != want {
			t.Fatalf("zone %d", zone)
		}
	}
	if EffectOff() != (TriggerEffect{5}) {
		t.Fatal("wrong Off")
	}
	e = EffectVibration(-1, 99, 999)
	if binary.LittleEndian.Uint16(e[1:3]) != 0x3ff || e[9] != 255 || binary.LittleEndian.Uint32(e[3:7]) != 0x3fffffff {
		t.Fatalf("clamps %x", e)
	}
}

func TestAutomaticBurstAndRelease(t *testing.T) {
	c := NewController(DefaultConfig())
	now := time.Unix(100, 0)
	baseline(c, now)
	for seq := uint64(1); seq <= 10; seq++ {
		now = now.Add(75 * time.Millisecond)
		if !c.ProcessSnapshot(now, shot(seq, "R")) {
			t.Fatal("rejected")
		}
		l, r := c.Effects(now.Add(74 * time.Millisecond))
		if l != EffectOff() || r[0] != 0x26 || r[9] != 13 {
			t.Fatalf("burst dropped at %d: %x %x", seq, l, r)
		}
	}
	_, r := c.Effects(now.Add(87 * time.Millisecond))
	if r != EffectOff() {
		t.Fatal("not released")
	}
}

func TestNoReplayAndHeartbeat(t *testing.T) {
	c := NewController(DefaultConfig())
	now := time.Unix(100, 0)
	c.ProcessSnapshot(now, shot(90, "R"))
	_, r := c.Effects(now)
	if r != EffectOff() {
		t.Fatal("replayed startup snapshot")
	}
	c.ProcessSnapshot(now, shot(91, "R"))
	c.ProcessSnapshot(now.Add(80*time.Millisecond), shot(91, "R"))
	_, r = c.Effects(now.Add(90 * time.Millisecond))
	if r != EffectOff() {
		t.Fatal("heartbeat prolonged shot")
	}
	if c.ProcessSnapshot(now, shot(89, "R")) {
		t.Fatal("regressing seq accepted")
	}
	s := shot(91, "R")
	s.Power = 1.2
	if c.ProcessSnapshot(now, s) {
		t.Fatal("changed same-seq shot accepted")
	}
}

func TestHandsAndStop(t *testing.T) {
	c := NewController(DefaultConfig())
	now := time.Unix(100, 0)
	baseline(c, now)
	c.ProcessSnapshot(now, shot(1, "L"))
	l, r := c.Effects(now)
	if l[0] != 0x26 || r != EffectOff() {
		t.Fatal("wrong left routing")
	}
	c.ProcessSnapshot(now, shot(2, "B"))
	l, r = c.Effects(now)
	if l[0] != 0x26 || r[0] != 0x26 {
		t.Fatal("wrong both routing")
	}
	s := shot(2, "B")
	s.Active = false
	c.ProcessSnapshot(now, s)
	l, r = c.Effects(now)
	if l != EffectOff() || r != EffectOff() {
		t.Fatal("inactive didn't clear")
	}
	s = shot(2, "B")
	c.ProcessSnapshot(now, s)
	l, r = c.Effects(now)
	if l != EffectOff() || r != EffectOff() {
		t.Fatal("reactivation replayed shot")
	}
}

func TestWatchdogAndSession(t *testing.T) {
	c := NewController(Config{Start: 3, Strength: 5, HeavyStrength: 7, Watchdog: 50 * time.Millisecond})
	now := time.Unix(100, 0)
	baseline(c, now)
	c.ProcessSnapshot(now, shot(1, "R"))
	_, r := c.Effects(now.Add(51 * time.Millisecond))
	if r != EffectOff() {
		t.Fatal("watchdog didn't release")
	}
	s := shot(1, "R")
	s.Session = "test2"
	c.ProcessSnapshot(now.Add(time.Second), s)
	_, r = c.Effects(now.Add(time.Second))
	if r != EffectOff() {
		t.Fatal("session replay")
	}
}

func TestConfigurationAndHeavy(t *testing.T) {
	c := NewController(Config{Start: 99, Strength: 99, HeavyStrength: 99, Watchdog: time.Hour})
	if c.config.Start != 9 || c.config.Strength != 8 || c.config.HeavyStrength != 8 || c.config.Watchdog != 350*time.Millisecond {
		t.Fatal("config not clamped")
	}
	s := shot(1, "R")
	s.Kind = "Shotgun"
	e, d := c.shotEffect(s)
	if e[9] != 25 || d != 70*time.Millisecond {
		t.Fatal("heavy pattern")
	}
	s.Kind = "SubmachineGun"
	s.Cycle = 0.001
	e, d = c.shotEffect(s)
	if e[9] != 30 || d != 65*time.Millisecond {
		t.Fatal("fast clamp")
	}
	s.Cycle = 9
	e, d = c.shotEffect(s)
	if e[9] != 8 || d != 160*time.Millisecond {
		t.Fatal("slow clamp")
	}
}

func TestParseSnapshot(t *testing.T) {
	valid := "version=1 session=test_01 seq=12 active=1 hand=R kind=SubmachineGun cycle=0.075 power=1.2\n"
	s, err := ParseSnapshot([]byte(valid))
	if err != nil || s.Seq != 12 || s.Cycle != 0.075 {
		t.Fatalf("parse %v %v", s, err)
	}
	if _, err := ParseSnapshot([]byte(valid + "tick=42")); err != nil {
		t.Fatalf("optional heartbeat: %v", err)
	}
	bad := []string{"", valid + "seq=1", "version=1 session=x seq=0 active=1 hand=R kind=SMG cycle=NaN power=1", "version=1 session=x seq=0 active=1 hand=R kind=SMG cycle=.1 power=Inf", "version=1 session=x seq=-1 active=1 hand=R kind=SMG cycle=.1 power=1", "version=1 session=x seq=1 active=2 hand=R kind=SMG cycle=.1 power=1", "version=1 session=x seq=1 active=1 hand=X kind=SMG cycle=.1 power=1"}
	for _, v := range bad {
		if _, err := ParseSnapshot([]byte(v)); err == nil {
			t.Fatalf("accepted %q", v)
		}
	}
}
