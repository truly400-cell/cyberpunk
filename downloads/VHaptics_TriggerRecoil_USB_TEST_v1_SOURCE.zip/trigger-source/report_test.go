package main

import "testing"

func TestUSBTriggerReportIsolation(t *testing.T) {
	v := EffectVibration(3, 5, 13)
	for _, size := range []int{48, 63, 65} {
		r, owned := makeUSBReport(size, EffectOff(), v, false)
		if owned || len(r) != size || r[0] != 2 || r[1] != 4 {
			t.Fatalf("invalid R2 report size/flags: %x", r)
		}
		for i := range r {
			expected := byte(0)
			if i == 0 {
				expected = 2
			}
			if i == 1 {
				expected = 4
			}
			if i >= 11 && i < 22 {
				expected = v[i-11]
			}
			if r[i] != expected {
				t.Fatalf("unexpected byte %d: %x != %x", i, r[i], expected)
			}
		}
	}
}

func TestUSBLeftOwnershipAndRelease(t *testing.T) {
	v := EffectVibration(3, 5, 13)
	r, owned := makeUSBReport(48, v, v, false)
	if !owned || r[1] != 12 || r[22] != 0x26 {
		t.Fatal("left activation missing")
	}
	r, owned = makeUSBReport(48, EffectOff(), EffectOff(), owned)
	if owned || r[1] != 12 || r[22] != 5 || r[11] != 5 {
		t.Fatal("left release missing")
	}
	r, _ = makeUSBReport(48, EffectOff(), EffectOff(), owned)
	if r[1] != 4 {
		t.Fatal("inactive left should no longer be selected")
	}
	for _, size := range []int{0, 47, 66, 78} {
		if r, _ := makeUSBReport(size, v, v, false); r != nil {
			t.Fatal("unsupported report size accepted")
		}
	}
}
