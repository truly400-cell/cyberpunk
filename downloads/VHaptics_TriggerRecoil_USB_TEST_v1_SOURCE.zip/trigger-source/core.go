package main

import (
	"encoding/binary"
	"errors"
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
)

// TriggerEffect is the DualSense's eleven-byte adaptive trigger effect block.
// Packet transport flags belong to the platform backend, not to this block.
type TriggerEffect [11]byte

func clampInt(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func EffectOff() TriggerEffect { return TriggerEffect{0x05} }

// EffectVibration uses the documented mode 0x26 (ten-zone vibration).
// Each active zone has a three-bit amplitude of strength-1. Frequency is Hz.
// Source: yesbotics/dualsense-controller-python, TriggerEffectProperty.vibration.
func EffectVibration(start, strength, frequency int) TriggerEffect {
	start = clampInt(start, 0, 9)
	strength = clampInt(strength, 1, 8)
	frequency = clampInt(frequency, 1, 255)
	e := TriggerEffect{0x26}
	var zones uint16
	var amplitudes uint32
	for zone := start; zone < 10; zone++ {
		zones |= 1 << uint(zone)
		amplitudes |= uint32(strength-1) << uint(3*zone)
	}
	binary.LittleEndian.PutUint16(e[1:3], zones)
	binary.LittleEndian.PutUint32(e[3:7], amplitudes)
	e[9] = byte(frequency)
	return e
}

type Snapshot struct {
	Version      int
	Session      string
	Seq          uint64
	Active       bool
	Hand, Kind   string
	Cycle, Power float64
}

func identifier(s string) bool {
	if len(s) == 0 || len(s) > 64 {
		return false
	}
	for _, r := range s {
		if !(r >= 'a' && r <= 'z' || r >= 'A' && r <= 'Z' || r >= '0' && r <= '9' || r == '_' || r == '-') {
			return false
		}
	}
	return true
}

func validSnapshot(s Snapshot) bool {
	return s.Version == 1 && identifier(s.Session) && identifier(s.Kind) &&
		(s.Hand == "R" || s.Hand == "L" || s.Hand == "B") &&
		!math.IsNaN(s.Cycle) && !math.IsInf(s.Cycle, 0) && s.Cycle >= 0 && s.Cycle <= 10 &&
		!math.IsNaN(s.Power) && !math.IsInf(s.Power, 0) && s.Power >= 0 && s.Power <= 4
}

// ParseSnapshot rejects incomplete/truncated writes. The producer writes plain
// ASCII key=value fields separated by whitespace, with no data outside this set.
func ParseSnapshot(b []byte) (Snapshot, error) {
	var s Snapshot
	if len(b) > 2048 {
		return s, errors.New("snapshot too large")
	}
	fields := make(map[string]string)
	for _, word := range strings.Fields(string(b)) {
		kv := strings.SplitN(word, "=", 2)
		if len(kv) != 2 || kv[1] == "" {
			return s, errors.New("invalid field")
		}
		if _, exists := fields[kv[0]]; exists {
			return s, errors.New("duplicate field")
		}
		fields[kv[0]] = kv[1]
	}
	keys := []string{"version", "session", "seq", "active", "hand", "kind", "cycle", "power"}
	if tick, ok := fields["tick"]; ok {
		if _, err := strconv.ParseUint(tick, 10, 64); err != nil {
			return s, errors.New("invalid heartbeat tick")
		}
		delete(fields, "tick")
	}
	if len(fields) != len(keys) {
		return s, errors.New("wrong field count")
	}
	for _, k := range keys {
		if _, ok := fields[k]; !ok {
			return s, fmt.Errorf("missing %s", k)
		}
	}
	var err error
	if s.Version, err = strconv.Atoi(fields["version"]); err != nil {
		return s, err
	}
	if s.Seq, err = strconv.ParseUint(fields["seq"], 10, 64); err != nil {
		return s, err
	}
	if s.Cycle, err = strconv.ParseFloat(fields["cycle"], 64); err != nil {
		return s, err
	}
	if s.Power, err = strconv.ParseFloat(fields["power"], 64); err != nil {
		return s, err
	}
	if fields["active"] != "0" && fields["active"] != "1" {
		return s, errors.New("invalid active value")
	}
	s.Session, s.Hand, s.Kind, s.Active = fields["session"], fields["hand"], fields["kind"], fields["active"] == "1"
	if !validSnapshot(s) {
		return s, errors.New("snapshot values out of range")
	}
	return s, nil
}

type Config struct {
	Start, Strength, HeavyStrength int
	Watchdog                       time.Duration
}

func DefaultConfig() Config {
	return Config{Start: 3, Strength: 5, HeavyStrength: 7, Watchdog: 350 * time.Millisecond}
}

func (c Config) normalized() Config {
	c.Start = clampInt(c.Start, 0, 9)
	c.Strength = clampInt(c.Strength, 1, 8)
	c.HeavyStrength = clampInt(c.HeavyStrength, 1, 8)
	if c.Watchdog < 50*time.Millisecond {
		c.Watchdog = 50 * time.Millisecond
	}
	if c.Watchdog > 350*time.Millisecond {
		c.Watchdog = 350 * time.Millisecond
	}
	return c
}

type handState struct {
	effect TriggerEffect
	until  time.Time
}

type Controller struct {
	config      Config
	initialized bool
	last        Snapshot
	lastSeen    time.Time
	left, right handState
}

func NewController(c Config) *Controller { return &Controller{config: c.normalized()} }

func (c *Controller) clear() { c.left, c.right = handState{}, handState{} }

func sameShot(a, b Snapshot) bool {
	return a.Hand == b.Hand && a.Kind == b.Kind && a.Cycle == b.Cycle && a.Power == b.Power
}

// ProcessSnapshot must only be called for a newly written, fresh state file.
// Calling this repeatedly for an unchanged file would keep the watchdog alive.
// A session's first snapshot is a baseline, never a replayed shot on startup.
func (c *Controller) ProcessSnapshot(now time.Time, s Snapshot) bool {
	if !validSnapshot(s) {
		return false
	}
	if !c.initialized || s.Session != c.last.Session {
		c.clear()
		c.initialized, c.last, c.lastSeen = true, s, now
		return true
	}
	if s.Seq < c.last.Seq || s.Seq == c.last.Seq && !sameShot(s, c.last) {
		return false
	}
	newShot := s.Seq > c.last.Seq
	c.last, c.lastSeen = s, now
	if !s.Active {
		c.clear()
		return true
	}
	if !newShot {
		return true
	}
	effect, duration := c.shotEffect(s)
	h := handState{effect: effect, until: now.Add(duration)}
	if s.Hand == "L" || s.Hand == "B" {
		c.left = h
	}
	if s.Hand == "R" || s.Hand == "B" {
		c.right = h
	}
	return true
}

func automatic(kind string) bool {
	switch kind {
	case "SubmachineGun", "AssaultRifle", "Rifle", "LightMachineGun", "HeavyMachineGun", "ShotgunAuto":
		return true
	}
	return false
}

func (c *Controller) shotEffect(s Snapshot) (TriggerEffect, time.Duration) {
	strength, frequency := c.config.HeavyStrength, 25
	duration := 70 * time.Millisecond
	if automatic(s.Kind) {
		cycle := s.Cycle
		if cycle <= 0 {
			cycle = 0.08
		}
		frequency = clampInt(int(math.Round(1/cycle)), 8, 30)
		duration = time.Duration(cycle * 1.15 * float64(time.Second))
		if duration < 65*time.Millisecond {
			duration = 65 * time.Millisecond
		}
		if duration > 160*time.Millisecond {
			duration = 160 * time.Millisecond
		}
		strength = c.config.Strength
	}
	power := math.Max(0.75, math.Min(1.5, s.Power))
	strength = clampInt(int(math.Round(float64(strength)*power)), 1, 8)
	return EffectVibration(c.config.Start, strength, frequency), duration
}

// Effects returns left first, right second. Expired outputs always become Off.
func (c *Controller) Effects(now time.Time) (TriggerEffect, TriggerEffect) {
	if !c.initialized || now.Sub(c.lastSeen) > c.config.Watchdog {
		c.clear()
		return EffectOff(), EffectOff()
	}
	left, right := EffectOff(), EffectOff()
	if now.Before(c.left.until) {
		left = c.left.effect
	}
	if now.Before(c.right.until) {
		right = c.right.effect
	}
	return left, right
}
