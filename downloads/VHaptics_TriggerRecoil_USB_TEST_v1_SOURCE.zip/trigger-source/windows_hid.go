//go:build windows

package main

// Windows HID output layout reference (USB ID 0x02, valid_flag0 bit 2,
// right trigger effect at byte 11):
// https://github.com/yesbotics/dualsense-controller-python/blob/main/src/dualsense_controller/core/report/out_report/Usb01OutReport.py
// Right trigger is owned; left trigger is updated only while active and once to clear.
// Never select legacy rumble,
// audio, lightbar, microphone or left trigger updates.

import (
	"encoding/binary"
	"errors"
	"fmt"
	"runtime"
	"strings"
	"syscall"
	"unsafe"
)

var (
	hidDLL           = syscall.NewLazyDLL("hid.dll")
	setupDLL         = syscall.NewLazyDLL("setupapi.dll")
	kernelDLL        = syscall.NewLazyDLL("kernel32.dll")
	hidGetGUID       = hidDLL.NewProc("HidD_GetHidGuid")
	hidAttrs         = hidDLL.NewProc("HidD_GetAttributes")
	hidPreparsed     = hidDLL.NewProc("HidD_GetPreparsedData")
	hidFreePreparsed = hidDLL.NewProc("HidD_FreePreparsedData")
	hidCaps          = hidDLL.NewProc("HidP_GetCaps")
	setupGetClass    = setupDLL.NewProc("SetupDiGetClassDevsW")
	setupEnum        = setupDLL.NewProc("SetupDiEnumDeviceInterfaces")
	setupDetail      = setupDLL.NewProc("SetupDiGetDeviceInterfaceDetailW")
	setupDestroy     = setupDLL.NewProc("SetupDiDestroyDeviceInfoList")
	createEvent      = kernelDLL.NewProc("CreateEventW")
	cancelIO         = kernelDLL.NewProc("CancelIoEx")
	overlappedResult = kernelDLL.NewProc("GetOverlappedResult")
	createMutex      = kernelDLL.NewProc("CreateMutexW")
)

type hidInterface struct {
	Size     uint32
	GUID     syscall.GUID
	Flags    uint32
	Reserved uintptr
}
type hidAttributes struct {
	Size      uint32
	VendorID  uint16
	ProductID uint16
	Version   uint16
}

type hidDevice struct {
	handle     syscall.Handle
	reportSize int
	name       string
	leftOwned  bool
}

// Keep buffers alive if a pathological driver does not acknowledge cancellation.
// Closing a device requests cancellation; do not reuse/free an unfinished IRP buffer.
type heldIO struct {
	data  []byte
	ov    *syscall.Overlapped
	event syscall.Handle
}

var unfinishedIO []heldIO

func openDualSenseUSB() (*hidDevice, error) {
	var guid syscall.GUID
	hidGetGUID.Call(uintptr(unsafe.Pointer(&guid)))
	set, _, err := setupGetClass.Call(uintptr(unsafe.Pointer(&guid)), 0, 0, 0x12)
	if set == ^uintptr(0) {
		return nil, fmt.Errorf("enumerate HID interfaces: %w", err)
	}
	defer setupDestroy.Call(set)
	var reasons []string
	for i := uint32(0); ; i++ {
		inf := hidInterface{}
		inf.Size = uint32(unsafe.Sizeof(inf))
		ok, _, enumErr := setupEnum.Call(set, 0, uintptr(unsafe.Pointer(&guid)), uintptr(i), uintptr(unsafe.Pointer(&inf)))
		if ok == 0 {
			if enumErr != syscall.Errno(259) {
				reasons = append(reasons, fmt.Sprintf("enumeration: %v", enumErr))
			}
			break
		}
		var needed uint32
		setupDetail.Call(set, uintptr(unsafe.Pointer(&inf)), 0, 0, uintptr(unsafe.Pointer(&needed)), 0)
		if needed < 8 || needed > 65536 {
			continue
		}
		detail := make([]byte, needed)
		// SP_DEVICE_INTERFACE_DETAIL_DATA_W.cbSize is 8 on Win64; DevicePath starts at offset 4.
		binary.LittleEndian.PutUint32(detail[:4], 8)
		ok, _, _ = setupDetail.Call(set, uintptr(unsafe.Pointer(&inf)), uintptr(unsafe.Pointer(&detail[0])), uintptr(needed), 0, 0)
		if ok == 0 {
			continue
		}
		chars := unsafe.Slice((*uint16)(unsafe.Pointer(&detail[4])), (len(detail)-4)/2)
		path := syscall.UTF16ToString(chars)
		low := strings.ToLower(path)
		if !strings.Contains(low, "vid_054c") || (!strings.Contains(low, "pid_0ce6") && !strings.Contains(low, "pid_0df2")) {
			continue
		}
		path16, e := syscall.UTF16PtrFromString(path)
		if e != nil {
			continue
		}
		handle, e := syscall.CreateFile(path16, syscall.GENERIC_READ|syscall.GENERIC_WRITE, syscall.FILE_SHARE_READ|syscall.FILE_SHARE_WRITE, nil, syscall.OPEN_EXISTING, syscall.FILE_ATTRIBUTE_NORMAL|syscall.FILE_FLAG_OVERLAPPED, 0)
		if e != nil {
			reasons = append(reasons, fmt.Sprintf("Sony device open failed: %v (close DSX/DS4Windows or unhide device)", e))
			continue
		}
		attrs := hidAttributes{Size: uint32(unsafe.Sizeof(hidAttributes{}))}
		ok, _, _ = hidAttrs.Call(uintptr(handle), uintptr(unsafe.Pointer(&attrs)))
		if ok == 0 || attrs.VendorID != 0x054c || (attrs.ProductID != 0x0ce6 && attrs.ProductID != 0x0df2) {
			syscall.CloseHandle(handle)
			continue
		}
		var pp uintptr
		ok, _, _ = hidPreparsed.Call(uintptr(handle), uintptr(unsafe.Pointer(&pp)))
		if ok == 0 {
			syscall.CloseHandle(handle)
			continue
		}
		caps := make([]byte, 64)
		status, _, _ := hidCaps.Call(pp, uintptr(unsafe.Pointer(&caps[0])))
		hidFreePreparsed.Call(pp)
		if status != 0x00110000 {
			syscall.CloseHandle(handle)
			continue
		}
		usage := binary.LittleEndian.Uint16(caps[:2])
		page := binary.LittleEndian.Uint16(caps[2:4])
		size := int(binary.LittleEndian.Uint16(caps[6:8]))
		if usage != 5 || page != 1 {
			syscall.CloseHandle(handle)
			continue
		}
		if size == 78 {
			reasons = append(reasons, "Bluetooth DualSense found; this build requires USB for original VHaptics audio and trigger output")
			syscall.CloseHandle(handle)
			continue
		}
		if size < 48 || size > 65 {
			reasons = append(reasons, fmt.Sprintf("unsupported HID output report length %d", size))
			syscall.CloseHandle(handle)
			continue
		}
		name := "DualSense USB"
		if attrs.ProductID == 0x0df2 {
			name = "DualSense Edge USB"
		}
		return &hidDevice{handle: handle, reportSize: size, name: name}, nil
	}
	if len(reasons) != 0 {
		return nil, errors.New(strings.Join(reasons, "; "))
	}
	return nil, errors.New("no USB DualSense/Edge found; connect by USB and close DSX/DS4Windows; HidHide must allow this helper")
}

func (d *hidDevice) close() {
	if d != nil && d.handle != 0 && d.handle != syscall.InvalidHandle {
		syscall.CloseHandle(d.handle)
		d.handle = 0
	}
}

func (d *hidDevice) send(left, right TriggerEffect) error {
	if d == nil || d.handle == 0 {
		return errors.New("controller not open")
	}
	report, nextLeftOwned := makeUSBReport(d.reportSize, left, right, d.leftOwned)
	ev, _, err := createEvent.Call(0, 1, 0, 0)
	if ev == 0 {
		return fmt.Errorf("create HID completion event: %w", err)
	}
	event := syscall.Handle(ev)
	ov := &syscall.Overlapped{HEvent: event}
	defer func() { runtime.KeepAlive(report); runtime.KeepAlive(ov) }()
	var done uint32
	writeErr := syscall.WriteFile(d.handle, report, &done, ov)
	if writeErr != nil && writeErr != syscall.ERROR_IO_PENDING {
		syscall.CloseHandle(event)
		return fmt.Errorf("HID output: %w", writeErr)
	}
	if writeErr == syscall.ERROR_IO_PENDING {
		wait, waitErr := syscall.WaitForSingleObject(event, 100)
		if waitErr != nil || wait != syscall.WAIT_OBJECT_0 {
			cancelIO.Call(uintptr(d.handle), uintptr(unsafe.Pointer(ov)))
			wait, _ = syscall.WaitForSingleObject(event, 250)
			if wait != syscall.WAIT_OBJECT_0 {
				unfinishedIO = append(unfinishedIO, heldIO{report, ov, event})
				d.close()
				return errors.New("HID write timed out and driver did not finish cancellation; reconnect controller")
			}
			syscall.CloseHandle(event)
			runtime.KeepAlive(report)
			runtime.KeepAlive(ov)
			return errors.New("HID write timed out; close other controller software and reconnect")
		}
		ok, _, resultErr := overlappedResult.Call(uintptr(d.handle), uintptr(unsafe.Pointer(ov)), uintptr(unsafe.Pointer(&done)), 0)
		if ok == 0 {
			syscall.CloseHandle(event)
			return fmt.Errorf("complete HID output: %w", resultErr)
		}
	}
	syscall.CloseHandle(event)
	runtime.KeepAlive(report)
	runtime.KeepAlive(ov)
	if int(done) != len(report) {
		return fmt.Errorf("short HID report: %d of %d bytes", done, len(report))
	}
	d.leftOwned = nextLeftOwned
	return nil
}

func acquireInstance() (syscall.Handle, error) {
	name, _ := syscall.UTF16PtrFromString("Local\\VHapticsTriggers-USB-v1")
	h, _, err := createMutex.Call(0, 0, uintptr(unsafe.Pointer(name)))
	if h == 0 {
		return 0, fmt.Errorf("create single-instance mutex: %w", err)
	}
	if err == syscall.Errno(183) {
		syscall.CloseHandle(syscall.Handle(h))
		return 0, errors.New("VHapticsTriggers is already running; use --stop first")
	}
	return syscall.Handle(h), nil
}
