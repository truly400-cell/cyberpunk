# VHaptics Trigger Recoil USB test build source

The new Go helper is in trigger-source/. No third-party Go modules are required.
Original VHaptics audio EXE, CSV and redscripts are not rebuilt. Only init.lua and
modules/events.lua receive small hooks; new Lua bridge is modules/triggers.lua.

Build from trigger-source with Go (this binary used official Go1.27.3):
```
go test -buildvcs=false -count=1 -v ./...
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet -buildvcs=false ./...
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -buildvcs=false -o VHapticsTriggers.exe .
```
On Windows set GOOS/GOARCH/CGO_ENABLED in the shell's environment first, then run go build.
Output is a console EXE; USB I/O and physical controller behavior are not validated here.

Lua integration checks use Python and lupa (`python -m pip install lupa`):
```
python tests/test_lua_bridge.py
```
The tests mock game state and file I/O; they cannot verify CET's actual native bindings.
See README_TriggerRecoil_KO.txt for installation and hardware caveats.
Protocol references are cited directly in Go source files; no Nexus files were fetched.
