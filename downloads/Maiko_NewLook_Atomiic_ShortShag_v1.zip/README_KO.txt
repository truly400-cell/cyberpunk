Maiko New Look — Atomiic Short Shag Hair v1

사용자가 제공한 Maiko New Look - New outfit - Alt version 및
Atomiic Short Shag Hair CCXL 파일을 WolvenKit Console 8.18.0으로 작업했습니다.

설치
1. Cyberpunk 2077을 완전히 종료합니다.
2. 기존 !_Tyger_Claws_gang_NewLook_Maiko_Alt_V1.archive를 게임 폴더 밖으로
   옮겨 백업합니다. 마에코 외형을 변경하는 다른 모드와도 함께 쓰지 마세요.
3. ZIP의 archive 폴더를 Cyberpunk 2077 설치 폴더에 풀어 넣습니다.
   최종 위치:
   Cyberpunk 2077\archive\pc\mod\!_Maiko_NewLook_Atomiic_ShortShag_v1.archive
4. ArchiveXL과 그 버전에 호환되는 RED4ext가 필요합니다.
   아토믹 헤어의 동적 재질을 사용하므로 이 요구 사항을 유지해야 합니다.
   필요한 헤어 리소스는 결과물에 포함되어 있어 원본 아토믹 CCXL 모드를
   별도로 설치할 필요는 없습니다.

내용
- 마에코 일반/캐주얼 외형의 헤어 메시와 다이내믹 리그를 아토믹 쇼트 섀그로 교체.
- 기존 머리색 유지: 일반 외형 brown_medium, 캐주얼 외형 pink_rose.
- 포토모드용 마에코 외형에도 같은 교체 적용.
  원본의 포토모드 기능과 관련 외부 의존성은 그대로 유지합니다.
- 얼굴, 의상 및 나머지 원본 리소스 유지.
- 플레이어용 그림자 메시의 shadow_ 뼈 이름을 NPC 뼈 이름으로 조정.
- 플레이어 커스터마이징 메뉴를 추가하는 CCXL 등록 파일은 포함하지 않음.

복구
게임을 종료하고 새 .archive를 제거한 뒤 백업한 원본 Maiko .archive를 복원합니다.

검증 범위
파일 구조, 압축 무결성, 재추출 및 헤어 변경 외 데이터 보존을 검사했습니다.
실제 게임은 이 클라우드 환경에 설치되어 있지 않아 실행 검증하지 못했습니다.
두피 밀착, 동작 중 헤어/의상 간섭, 그림자는 게임 안에서 확인해야 합니다.

원본 제작자의 리소스를 사용한 사용자 요청용 수정본입니다.
