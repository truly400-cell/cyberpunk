EDW3.7 양손 위치·회전 맞춤 패치 v4 TEST

변경
v3는 오른손의 회전만 바꿔 긴 총기의 오른쪽 손·무기 위치가 왼쪽과 맞지 않았습니다.
v4는 왼쪽 어깨/팔/팔꿈치/손/무기의 모델 공간 위치를 먼저 읽고,
오른쪽을 좌우 대칭 위치와 회전으로 배치합니다. 왼쪽 포즈와 오른손 권총/리볼버는 보존합니다.
추가 기울기는 기본 0도입니다. 이전 버전 angle=45 설정은 추가 보정 0도로 이전합니다.
왼손의 기울기 자체를 복사하므로 45도를 다시 더하면 이중 기울기가 됩니다.
무기 모델 크기가 서로 다르면 화면상의 총기 외곽선까지 똑같아지지는 않습니다.

설치
1. 게임을 완전히 종료합니다.
2. 원본 Expanded Dual Wielding3.7은 켜둡니다.
3. 이전 v1/v2/v3 기울기 패치는 끄고 v4만 켭니다.
   수동 설치: ZIP의 archive/bin/r6를 Cyberpunk2077 설치 폴더에 같은 경로로 덮어씁니다.
   중복 방지를 위해 내부 archive 파일명은 이전과 같습니다.
   !!!!_EDW_RightHand_AimCant_v1_TEST.archive라는 이름이어도 이 ZIP의 내용은 v4입니다.
4. 게임을 다시 실행하고 양손 SMG/AR/산탄총 등의 상태에서 LT로 조준합니다.
   CET의 EDW Matched Dual-Gun Pose 창에서 Match 체크, Extra roll trim=0을 사용합니다.
   독립 조작 옵션을 켤 필요는 없습니다. CET를 닫으면 변경이 적용됩니다.
   Reload all mods만으로는 새 redscript/그래프가 로드되지 않습니다.

적용 범위
오른손이 권총/리볼버가 아닌 원거리 쌍수 조준 중에만 맞춤 포즈로 전환합니다.
CameraAim 입력 또는 상체 조준 상태를 사용하고, 약0.1초에 전환합니다.
단일 무기/근접 혼합/사이버웨어/재장전/무기 교체/메뉴/차량/비생존 상태는 제외합니다.
Extra roll trim은 -20~20도이며 0도가 대칭 기본값입니다.

진단
양손에 대상 무기를 들고 CET에서 Test pose for 3s after closing CET를 누른 뒤
CET를 닫으면 LT를 누르지 않아도 약3초간 맞춤 포즈를 요청합니다.
GetMod("EDWRightCant").test()
GetMod("EDWRightCant").status()
status에 [EDWRightCant v4]가 표시되어야 합니다.
weight=1: 직전 게임 업데이트의 맞춤 포즈 요청. lastWeight=1: 최근 조준/테스트에서 켜졌음.
trim=0/effectiveTrim=0이어도 weight=1이면 활성 상태입니다.
reason=active/test_pose: 대상 조준/테스트, not_aiming: 조준하지 않음.
reason=pistol_pose_preserved: 오른손 권총/리볼버 원본 유지, disabled: 설정OFF.
상태 값은 스크립트 요청이며 실제 그래프 평가/아카이브 우선순위의 증명은 아닙니다.
status는 게임 중 저장한 숫자·문자열만 읽고 플레이어 객체에 접근하지 않습니다.

종료 크래시 관련 수정
제공된 로그에는 CET 종료 경로의 무기/아이템/스탯 파괴 중 널 포인터 접근이 있습니다.
EDW 코드가 직접 지목되지는 않아 원인을 이 패치 하나로 확정할 수 없습니다.
다만 이전 패치가 플레이어 객체를 보관하고 onShutdown에서 무기/애니메이션 관련
네이티브 코드를 호출한 것은 안전하지 않았으므로 제거했습니다.
v4는 플레이어 객체를 보관하지 않으며 OnDetach 이전에 업데이트를 차단합니다.
onShutdown은 Lua 상태만 정리하며 게임 API/네이티브 함수/강제 GC를 호출하지 않습니다.
크래시 보고 기능을 숨기거나 끄지 않습니다. 실제 종료 크래시 해결 여부는 게임 검증이 필요합니다.
다른 모드의 종료 경로 오류까지 이 수정으로 해결했다고 보장할 수는 없습니다.

검증 범위
공식 WolvenKit8.18.0으로 변환/패킹/재추출 및 그래프 연결/초기화 등록을 검사합니다.
공개 참조 뼈대로 대칭 계산과 무작위128포즈를 검사했습니다.
CET 설정 이전, 활성화, 상태 스냅샷, 분리/종료 후 네이티브 접근 차단을 모의 테스트합니다.
공개 참조 뼈대는 실제 게임 플레이어 뼈대와 같지 않습니다.
Windows 게임 로딩/redscript 컴파일/실제 위치·회전/게임 종료는 이 환경에서 검증하지 못했습니다.
원본 EDW3.7 전용이며 다른 player_base 변경 모드와 충돌할 수 있습니다.
정확한 수행 결과와 한계는 validation-report.json에 있습니다.

제거
게임 종료 후 아래 패치 경로만 제거합니다. 원본 EDW3.7은 유지합니다.
archive/pc/mod/!!!!_EDW_RightHand_AimCant_v1_TEST.archive
r6/scripts/EDWRightCant/
bin/x64/plugins/cyber_engine_tweaks/mods/EDWRightCant/
